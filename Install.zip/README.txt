---------------------------------------
How To Install and Use WallpaperChanger
---------------------------------------

Step 1:
------
       First run, vc_redist.x86 for visual c++ binaries.
       In the Install file, run setup_loc12345.exe, and set the location of your wallpaper folder.Press        Install.
   NOTE: Please enter the correct path, else the application may fail.
         If you would like to change the wallpaper directory location later, always follow step 1.
         Step2 is not required, if the application has been executed before. 

Step 2:
------
       In the Run file, set a desktop shortcut of "Change.exe".      
       You can rename, change icon of the shortcut.
       Please change run status of the shortcut(in properties) to minimized. 
       Simple double clicking the shortcut, changes the wallpaper.
       

------------------------------------
Thank You for using SJ Technologies.
------------------------------------